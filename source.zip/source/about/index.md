---
layout: page
title: About
class: 'post'
navigation: True
logo: 'assets/images/ghost.png'
current: about
---

This is a demo blog for Ghost, it contains dummy content which allows you to click around and see what a Ghost blog running the default theme looks like.

We use this for testing and for reference!

If you'd like to set up your own blog, head on over to [https://ghost.org](https://ghost.org) and sign up.
